<?php
header('Content-type: text/html; charset=utf-8');
define('FLGR_BASE', $_SERVER['DOCUMENT_ROOT']);
require_once(FLGR_BASE.'/config.php');
require_once(FLGR_COMMON.'/common.php');	
$cdb_link = common_db_connect();
mysql_connect(DB_HOST, DB_USER, DB_PASSWORD) or die('database is down');
mysql_select_db(DB_NAME) or die ('dbconnect is down');
mysql_query('SET NAMES utf8');
mysql_query ("SET CHARACTER SET 'utf8'");
require_once(FLGR_COMMON.'/mailer.php');
$global=get_globals_arr();
$data_info="".$_POST['name']."<br>";
$data_info.="Телефон : ".$_POST['PhoneNumber']."<br>";
$data_info.="E-mail : ".$_POST['Email']."<br>";
$data_info.="url страницы : ".$_POST['url']."<br>";
	$mailer = new Mailer;
	$mailer->subject = "=?utf-8?B?". base64_encode($_POST['name']). "?=";
	$mailer->html = utf_to_cp1251($data_info);
	$mailer->from = $_POST['Email'];
	//$mailer->to = $global['EMAIL_REGISTR'];
	$mailer->to = "terra_82@mail.ru";
	if($_POST['Email']!='') {
		$mailer->Send();
	}
?>