<?php
die();
// No direct access.
defined('_JEXEC') or die;

JHTML::_('behavior.framework', true);

/* The following line gets the application object for things like displaying the site name */
$app = JFactory::getApplication();
$tplparams  = $app->getTemplate(true)->params;
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
  <jdoc:include type="head" />
  <!-- The following line loads the template CSS file located in the template folder. -->
  <link type="text/css" rel="stylesheet" href="/templates/siteground-j16-12/js/png.css" />
  <link type="text/css" rel="stylesheet" href="/templates/siteground-j16-12/js/floatbox/floatbox.css" />
  <script type="text/javascript" src="/templates/siteground-j16-12/js/floatbox/floatbox.js"></script>

  <script type="text/javascript" src="/templates/siteground-j16-12/js/webgfx.js"></script>
  <script type="text/javascript" src="/templates/siteground-j16-12/js/iepngfix.js"></script>
  <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/css/template.css" type="text/css" />
  



  
  
  
<!--<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery-1.9.0.js"></script>-->
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery-ui-1.9.2.custom.js"></script>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery-ui-1.9.2.custom.css" type="text/css" />
<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/prefab.js"></script>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/flexslider.css" type="text/css" />

<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery-ui-1.9.2.custom.css" type="text/css" />
<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/jquery.flexslider.js"></script>

  <script type="text/javascript" src="/templates/siteground-j16-12/js/immersive-slider-master/jquery.immersive-slider.js"></script>
  <link href='/templates/siteground-j16-12/js/immersive-slider-master/immersive-slider.css' rel='stylesheet' type='text/css'>
</head>
<body>
<div class="flex_wrap">
<a class="btn-red floatbox" rel="nofollow" href="http://sknorma.webtuner.ru/forms/31" rev="minContentWidth:1 minContentHeight:1 width: 860 height:460 infoPos:tc controlPos:tr">Обратный звонок</a>
<div class="flexslider">
<ul class="slides">
<li style="background-image:url('/templates/siteground-j16-12/images/slides/slide_1.jpg');">
<div class="caption_wrap"><div class="inside">
<div class="caption"><span>Ирлайн-Айс  — цельностеклянные перегородки с оптимальной звукоизоляцией</span></div></div></div></li>
<li style="background-image:url('/templates/siteground-j16-12/images/slides/slide_2.jpg');">
<div class="caption_wrap"><div class="inside">

<div class="caption"><span>Стационарные офисные перегородки Ирлайн-Универсал  — быстровозводимые сборные модульные конструкции</span></div></div></div></li>
<li style="background-image:url('/templates/siteground-j16-12/images/slides/slide_3.jpg');">
<div class="caption_wrap"><div class="inside">
<div class="caption"><span>Ирлайн-Оазис – это уникальная серия  закругленных и волнообразных профилей, позволяющая отойти от традиционных прямых форм</span></div></div></div></li>
<li style="background-image:url('/templates/siteground-j16-12/images/slides/slide_4.jpg');">
<div class="caption_wrap"><div class="inside">
<div class="caption"><span>Серия Ирлайн-Эдванс предназначена для создания респектабельных представительских интерьеров</span></div></div></div></li>
</ul>
</div>
</div>

<div class="header">
<div class="inside clearfix">
<div class="logo">
<img  src="/templates/siteground-j16-12/images/logo_new.jpg">
</div>
<div class="slogan">
<img src="/templates/siteground-j16-12/images/slogan.png">
</div>
</div>

<div class="contacts">
<div class="inside">
<div>
<div class="email">
<a href="mailto:info@irline.su">info@irline.su</a>
</div>
<div class="email">
<a href="mailto:zu@irline.su">zu@irline.su</a>
</div>
</div>
<div>
<div class="phone">
<span>8 (800)</span> 775-67-31
</div>
<!--<div class="phone">
<span>(499)</span> 707 79 08
</div>-->
</div>
</div>
</div>
<div class="menu">
<div class="inside">
<jdoc:include type="modules" name="position-3" />
<!--
<ul class="hmenu">
<li><a href="/promo-sait/informatciia/promo-sait#products">Продукция</a></li>
<li><a href="/promo-sait/informatciia/promo-sait#projects">Наши проекты</a></li>
<li><a href="/promo-sait/informatciia/promo-sait#priority">Приоритеты</a></li>
<li><a href="/promo-sait/informatciia/promo-sait#advant">Преимущества</a></li>
<li><a href="/promo-sait/informatciia/promo-sait#callback">Обратный звонок</a></li>
<li><a href="/promo-sait/informatciia/promo-sait#contacts">Контакты</a></li>
</ul>-->
</div>
</div>






</div>



<jdoc:include type="modules" name="position-8" />




<div class="priority"><a name="priority"></a>
<div class="inside">
<h2>Наши приоритеты</h2>
<div class="tab_priority">
<div><img src="/templates/siteground-j16-12/images/icon_priority_1.png">Решение<br/> нестандартных<br/> задач</div>
<div><img src="/templates/siteground-j16-12/images/icon_priority_2.png">Качество</div>
<div><img src="/templates/siteground-j16-12/images/icon_priority_3.png">Длительные<br/> партнерские<br/> отношения</div>
</div>
</div>
</div>

<div class="advant"><a name="advant"></a>
<div class="inside">
<h2>Наши преимущества</h2>
<ul>
<li>Российское производство офисных перегородок – гарантия быстрой, бесперебойной поставки комплектующих на объект</li>
<li>Гарантированное качество всех материалов и комплектующих</li>
<li>Оптимальная цена при высоком качестве</li>
<li>
Ускорение отделочных работ в разы, за счет модульности элементов перегородки, облицовки и технологичности сборки</li>
<li>
Чистая технология сборки – дает возможность монтировать перегородки в работающем офисе</li>
<li>
Гибкий график работ – при необходимости монтаж производится ночью, в выходные дни</li>
<li>
Минимальные сроки монтажа – сроки монтажа от Ваших, заданных нам сроков!</li></ul>

</div>
</div>

<iframe src="http://sknorma.webtuner.ru/callback" scrolling="no" class="frame_callback">

</iframe>


<div class="block_contacts">

<div class="inside">
<h2>Наши контакты</h2>
<div class="tab_wrap">
<div class="adress">
109263, г. Москва, <br/>
ул Шкулева, д.2А,<br/>
2 эт , кабинет 20
</div>
<div class="phone">
<span>8 (800)</span> 775-67-31
</div>
<div class="email">
<a href="mailto:info@irline.su">info@irline.su</a><br/>
<a href="mailto:zu@irline.su">zu@irline.su</a>
</div>
</div>
</div>

<iframe src="http://sknorma.webtuner.ru/forms/29/" class="frame_form">

</iframe>

<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2248.7532841120747!2d37.7464185!3d55.693276999999995!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x414ab45504b49811%3A0xdbfd625778d0b858!2z0YPQuy4g0KjQutGD0LvQtdCy0LAsIDLQkCwg0JzQvtGB0LrQstCwLCAxMDkyNjM!5e0!3m2!1sru!2sru!4v1425543446390"  frameborder="0" class="map_goo"></iframe>
</div>




<div class="projects">
<div class="inside">
<h2>Реализованные проекты</h2>
</div>
    <div class="main">
      <div class="page_container">
        <div id="immersive_slider">
          <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects1_2.jpg">
            <div class="content">
              <h2>Аэропорт в г. Белгороде</h2>
              <p>Монтаж перегородок "Универсал" с остеклением закаленным стеклом. Монтаж цельностеклянных перегородок на коннекторах. Монтаж дверей. Облицовка стен панелями "Эдванс". Отделка VIP зоны: облицовка шпонированными панелями стен и стелл с встроенными световыми панно.</p>
            </div>
            <div class="image">
              
                <img src="/templates/siteground-j16-12/images/projects1_1.jpg" alt="Аэропорт в г. Белгороде.">
              
            </div>
          </div>
          <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects2_2.jpg">
            <div class="content">
              <h2>Федеральная налоговая служба</h2>
              <p>Монтаж цельностеклянных перегородок, монтаж цельностеклянных дверей в арочный проем.<br/>
г. Москва, ул. Петровка 20\1</p>
            </div>
            <div class="image">
             <img src="/templates/siteground-j16-12/images/projects2_1.jpg" alt="Федеральная налоговая служба (ВИП офис)">
            </div>
          </div>
          <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects3_2.jpg">
            <div class="content">
              <h2>Группа Компаний «ДИКСИ»</h2>
              <p>Внутреняя отделка помещений. Строительство перегородок, облицовка стен, колонн. Монтаж раздвижных перегородок, сантехнических перегородок. Монтаж стойки ресепшен.
<br/>
г. Москва, Кировоградская 23, этаж 6</p>
            </div>
            <div class="image">
             <img src="/templates/siteground-j16-12/images/projects3_1.jpg" alt="Группа Компаний «ДИКСИ»">
            </div>
          </div>
      
      
      
      <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects4_2.jpg">
            <div class="content">
              <h2>ООО «Гермес-Групп»</h2>
              <p>Внутреняя отделка офиса облицовка панели Эдванс.<br/></p>
            </div>
            <div class="image">
             <img src="/templates/siteground-j16-12/images/projects4_1.jpg" alt="Группа Компаний «ДИКСИ»">
            </div>
          </div>
      
      
      
            <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects5_2.jpg">
            <div class="content">
              <h2>ЗАО «Ренессанс-Реставрация»</h2>
              <p>Генподрядчик ЗАО «Ренессанс-Реставрация», строительство для муниципальных нужд. Центр обслуживания населения. <br/>Новослободская, 45<br/></p>
            </div>
            <div class="image">
             <img src="/templates/siteground-j16-12/images/projects5_1.jpg" alt="Группа Компаний «ДИКСИ»">
            </div>
          </div>
      
      
      

      
                        <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects6_2.jpg">
            <div class="content">
              <h2>РЖД. Стоматология</h2>
              <p>Отделка стен панелями "Эдванс" . Монтаж перегородок с облицовкой панелями "Эдванс".<br/></p>
            </div>
            <div class="image">
             <img src="/templates/siteground-j16-12/images/projects6_1.jpg" alt="Группа Компаний «ДИКСИ»">
            </div>
          </div>
      
                        <div class="slide" data-blurred="/templates/siteground-j16-12/images/projects7_2.jpg">
            <div class="content">
              <h2>ВТБ 24</h2>
              <p>Специально разработанная перегородка для ВТБ банка, для отделений банка, зоны работы с Клиентом.<br/></p>
            </div>
            <div class="image">
             <img src="/templates/siteground-j16-12/images/projects7_1.jpg" alt="Группа Компаний «ДИКСИ»">
            </div>
          </div>
          
          <a href="#" class="is-prev">&laquo;</a>
          <a href="#" class="is-next">&raquo;</a>
        </div>
      </div>
    </div>
 
</div>


<div class="wrap_content" <?php if ($_SERVER['REQUEST_URI']=='/' or $_SERVER['REQUEST_URI']=='/index.php' )  {echo 'style="width:980px"';};?> >
<div class="inside">
    <jdoc:include type="modules" name="position-12" />
    <jdoc:include type="message" />
    <jdoc:include type="component" />
    <jdoc:include type="modules" name="debug" />
</div>
</div>


<div class="footer">

<div class="foot_menu"><jdoc:include type="modules" name="position-3" /></div>

<div class="inside">

<div class="co">
© 2002-2015 «СК Норма»

</div>

<div class="contacts">
<div class="phone"><span>8 (800)</span> 775-67-31.</div>
<div class="email">
<a href="mailto:info@irline.su">info@irline.su</a>
<br/>
<a href="mailto:zu@irline.su">zu@irline.su</a>
</div>
<div class="address">
Москва, ул Шкулева,<br/> д.2А, 2 эт , кабинет 20 </div>
</div>
<div class="soc">
<script type="text/javascript">(function() {
  if (window.pluso)if (typeof window.pluso.start == "function") return;
  if (window.ifpluso==undefined) { window.ifpluso = 1;
    var d = document, s = d.createElement('script'), g = 'getElementsByTagName';
    s.type = 'text/javascript'; s.charset='UTF-8'; s.async = true;
    s.src = ('https:' == window.location.protocol ? 'https' : 'http')  + '://share.pluso.ru/pluso-like.js';
    var h=d[g]('body')[0];
    h.appendChild(s);
  }})();</script>
<div class="pluso" data-background="transparent" data-options="small,square,line,horizontal,counter,theme=06" data-services="vkontakte,odnoklassniki,facebook,twitter"></div>
<a class="webdom" href="http://webdom.net" target="_blank">Создание сайта - Webdom</a>
</div>
</div>
</div>
<!--Yandex.Metrika counter-->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter14540044 = new Ya.Metrika({14540044,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) {}
    });

    var n = d.getElemantsByTagName("script")[0],
        s = d.createElement("script"),
        а = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.scr = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/mertika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img scr="//mc.yandex.ru/watch/14540044" style="position:absolute; left:-9999px;" alt="" /><div></noscript>
<!-- /Yandex.Metrika counter -->

<link rel="stylesheet" href="//cdn.callbackhunter.com/widget2/tracker.css">
<script type="text/javascript" 
src="//cdn.callbackhunter.com/widget2/tracker.js" charset="UTF-8"></script >
<script type="text/javascript">var hunter_code="0c216a1f844e82107db266b126f4199c";</script>

</body>
</html>


